Voice Recognition and Text to Speech on Android for Delphi, RAD Studio, C++Builder and Appmethod (C++ or Object Pascal).

Early stages. Still subject to heavy changes (like renaming and moving) but it works. 

There are two demos. The Google Glass one also includes voice launching and voice prompt support.

The TTS is based on [Jeff Overcash's Text to Speech translation](http://blogs.embarcadero.com/davidi/2013/09/28/42909).