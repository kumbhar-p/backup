# AIDLExampleProject
Sample app to show AIDL uses in Android
