#include<stdio.h>

int *insertion_sort(int *arr, int n)
{
	int i = 0, j;
	int key;

	for(i = 1; i < n; i++) {
		key = *(arr + i);
		for(j = i - 1; j >= 0 && key < *(arr + j); j--) 
			*(arr + j + 1) = *(arr + j);
			*(arr + j + 1) = key;
	}
	
	return arr;
}

