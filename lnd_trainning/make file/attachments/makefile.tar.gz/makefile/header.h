#include<stdio.h>
#include<stdlib.h>

int sum(int, int);
int sub(int, int);
int mul(int, int);
int dive(int, int);
