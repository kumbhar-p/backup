#include"header.h"
int sum(int a, int b)
{
	printf("welcome basu to Global edge\n");
	return (a + b);

}
