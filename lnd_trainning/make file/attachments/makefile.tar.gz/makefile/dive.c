#include"header.h"
int dive(int a, int b)
{
	return (a / b);

}
