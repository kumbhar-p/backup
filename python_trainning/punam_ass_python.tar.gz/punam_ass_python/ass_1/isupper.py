str1 = raw_input("enter the string :")
print "enter the option :"
print "1. isupper 2. islower"
op = input()
if op == 1:
    print str1.isupper()
else :
    if op == 2:
        print str1.islower()
    else :
        print "wrong option"
